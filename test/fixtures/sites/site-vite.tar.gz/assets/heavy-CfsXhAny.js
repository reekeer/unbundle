function o(t){const e=t.reduce((n,r)=>n+r.text.length,0);return{count:t.length,total:e,marker:"VITE_LAZY_CHUNK"}}export{o as summarize};
//# sourceMappingURL=heavy-CfsXhAny.js.map
