self.__BUILD_MANIFEST = {
  "/_error": [
    "static/chunks/051dprhxfclij.js"
  ],
  "/greet": [
    "static/chunks/27h0hh-dit-6r.js"
  ],
  "/greet/settings": [
    "static/chunks/32r_lz5v1m045.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error",
    "/greet",
    "/greet/settings"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()