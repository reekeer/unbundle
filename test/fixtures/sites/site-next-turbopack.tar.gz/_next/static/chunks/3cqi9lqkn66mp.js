(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,59355,t=>{"use strict";var e=t.i(43476),a=t.i(71645);t.s(["default",0,function({label:t}){let[s,c]=(0,a.useState)(!1);return(0,e.jsx)("span",{className:"badge","data-on":s,onClick:()=>c(!s),children:t})}])}]);

//# sourceMappingURL=0_01yiw9a30nj.js.map