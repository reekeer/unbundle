(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,38067,t=>{"use strict";t.s(["summarize",0,function(t){let e=t.reduce((t,e)=>t+e.text.length,0);return{count:t.length,total:e,marker:"UNBUNDLE_LAZY_CHUNK"}}])}]);

//# sourceMappingURL=3i2fzvxx2ulxw.js.map