__turbopack_load_page_chunks__("/_error", [
  "static/chunks/2ubf9v5n2ysnu.js",
  "static/chunks/10irri8ntv3jj.js",
  "static/chunks/21yjl89f35z56.js",
  "static/chunks/turbopack-2cc38y5o7jst9.js"
])
