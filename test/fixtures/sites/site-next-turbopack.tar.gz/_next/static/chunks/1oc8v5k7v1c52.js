(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,87323,t=>{"use strict";var e=t.i(71645);t.s(["default",0,function(){return(0,e.useEffect)(()=>{},[]),null}])}]);

//# sourceMappingURL=0hh5uuvlhlgb5.js.map