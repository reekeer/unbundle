__turbopack_load_page_chunks__("/_app", [
  "static/chunks/34lmq7dsqe-wf.js",
  "static/chunks/10irri8ntv3jj.js",
  "static/chunks/21yjl89f35z56.js",
  "static/chunks/turbopack-125n8ove8j1yd.js"
])
