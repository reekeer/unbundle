(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,71360,t=>{"use strict";var e=t.i(43476),s=t.i(71645);t.s(["default",0,function({value:t}){let[c]=(0,s.useState)(t);return(0,e.jsx)("b",{className:"late",children:c})}])}]);

//# sourceMappingURL=09vikf7sbrfr-.js.map