__turbopack_load_page_chunks__("/greet", [
  "static/chunks/0_e3t6agowyxd.js",
  "static/chunks/10irri8ntv3jj.js",
  "static/chunks/21yjl89f35z56.js",
  "static/chunks/turbopack-3f9-cx6u6h6up.js"
])
