__turbopack_load_page_chunks__("/greet/settings", [
  "static/chunks/40lo5nstfk399.js",
  "static/chunks/10irri8ntv3jj.js",
  "static/chunks/21yjl89f35z56.js",
  "static/chunks/turbopack-1vsnhd1b-d1rb.js"
])
