import{r as d}from"./index.-iFofLld.js";var x={exports:{}},e={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var c;function p(){if(c)return e;c=1;var s=Symbol.for("react.transitional.element"),u=Symbol.for("react.fragment");function n(o,r,t){var i=null;if(t!==void 0&&(i=""+t),r.key!==void 0&&(i=""+r.key),"key"in r){t={};for(var a in r)a!=="key"&&(t[a]=r[a])}else t=r;return r=t.ref,{$$typeof:s,type:o,key:i,ref:r!==void 0?r:null,props:t}}return e.Fragment=u,e.jsx=n,e.jsxs=n,e}var l;function v(){return l||(l=1,x.exports=p()),x.exports}var R=v();function f({initial:s}){const[u,n]=d.useState(s);return R.jsxs("div",{className:"react-counter",children:[R.jsxs("span",{children:["ASTRO_REACT ",u]}),R.jsx("button",{onClick:()=>n(o=>o+1),children:"+"})]})}export{f as default};
