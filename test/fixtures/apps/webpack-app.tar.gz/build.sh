#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
fixtures="${UNBUNDLE_FIXTURES:-$(dirname "$here")}"
work="$(mktemp -d "${TMPDIR:-/tmp}/unbundle-webpack-XXXXXX")"
trap 'rm -rf "$work"' EXIT
cp -r "$here/src" "$here/public" "$here/package.json" "$here/webpack.config.cjs" "$work/"
cd "$work"
bun install >/dev/null

site() {
  local out="$1" target="$2" main
  main=$(cd "$out/static/js" && ls main.*.js | grep -v '\.map$')
  cp public/pow.js public/challenge.html "$out/"
  sed "s#__MAIN__#$main#" public/index.html > "$out/index.html"
  mkdir -p "$fixtures/sites"
  COPYFILE_DISABLE=1 tar -czf "$fixtures/sites/$target.tar.gz" -C "$out" .
  echo "built $target"
}

OUT_DIR=out-webpack bun node_modules/webpack-cli/bin/cli.js --config webpack.config.cjs >/dev/null
site out-webpack site-webpack
OUT_DIR=out-rspack node node_modules/@rspack/cli/bin/rspack.js build --config webpack.config.cjs >/dev/null
site out-rspack site-rspack
