const path = require("node:path");
module.exports = {
  mode: "production",
  entry: "./src/main.js",
  devtool: "source-map",
  output: {
    path: path.resolve(__dirname, process.env.OUT_DIR || "out-webpack", "static/js"),
    filename: "main.[contenthash:8].js",
    chunkFilename: "[name].[contenthash:8].chunk.js",
    publicPath: "/static/js/",
    clean: true,
  },
};
