import { createElement as h, useState } from "react";
import { clamp, formatCount } from "./math.js";
import { useTodoStore } from "./store.js";

export default function App() {
  const [count, setCount] = useState(3);
  const [items, setItems] = useState([]);
  const total = useTodoStore((state) => state.total);
  const added = useTodoStore((state) => state.added);

  async function showSummary() {
    const { summarize } = await import("./heavy.js");
    console.log(summarize(items));
  }

  return h(
    "main",
    { className: "app" },
    h("h1", null, "WEBPACK_FIXTURE_TITLE"),
    h("p", null, formatCount(count)),
    h("button", { onClick: () => setCount((c) => clamp(c + 1, 0, 10)) }, "+"),
    h("button", { onClick: () => { setItems((prev) => [...prev, { id: prev.length + 1, text: "todo" }]); added(); } }, "Add"),
    h("button", { onClick: showSummary }, "Summary"),
    h("p", null, `WEBPACK_TOTAL ${total}`),
  );
}
