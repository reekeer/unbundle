export function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

export function formatCount(count) {
  return count === 1 ? "WEBPACK_ONE_ITEM" : `${count} items`;
}
