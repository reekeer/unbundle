export function summarize(items) {
  const total = items.reduce((sum, item) => sum + item.text.length, 0);
  return { count: items.length, total, marker: "WEBPACK_LAZY_CHUNK" };
}
