import { create } from "zustand";

export const useTodoStore = create((set) => ({
  total: 0,
  added: () => set((state) => ({ total: state.total + 1 })),
}));
