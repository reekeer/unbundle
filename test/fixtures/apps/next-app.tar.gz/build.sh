#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
fixtures="${UNBUNDLE_FIXTURES:-$(dirname "$here")}"
base="/t/tttt"
routes=("" about single siblings server nested empty deferred greet greet/settings)

capture() {
  local bundler="$1" target="$2"
  local work port server
  work="$(mktemp -d "${TMPDIR:-/tmp}/unbundle-next-XXXXXX")"
  port=$((40000 + RANDOM % 10000))
  cp -r "$here/app" "$here/components" "$here/lib" "$here/pages" "$here/public" "$here/package.json" "$here/next.config.mjs" "$here/postcss.config.mjs" "$work/"
  (
    cd "$work"
    export NEXT_TELEMETRY_DISABLED=1
    bun install >/dev/null
    bun --bun node_modules/next/dist/bin/next build "--$bundler" >/dev/null
    bun --bun node_modules/next/dist/bin/next start -p "$port" >/dev/null 2>&1 &
    server=$!
    trap 'kill "$server" 2>/dev/null || true' EXIT
    for _ in $(seq 1 80); do curl -sf "http://127.0.0.1:$port$base" >/dev/null && break; sleep 0.5; done
    mkdir -p captured/_next
    for route in "${routes[@]}"; do
      name="${route:-index}"
      mkdir -p "captured/$(dirname "$name")"
      curl -sfL "http://127.0.0.1:$port$base/$route" -o "captured/$name.html"
    done
    cp -r .next/static captured/_next/static
    cp -r public/. captured/
  )
  mkdir -p "$fixtures/sites"
  COPYFILE_DISABLE=1 tar -czf "$fixtures/sites/$target.tar.gz" -C "$work/captured" .
  rm -rf "$work"
  echo "captured $target ($bundler)"
}

capture webpack site-next
capture turbopack site-next-turbopack
