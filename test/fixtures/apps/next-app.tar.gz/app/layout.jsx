import "./globals.css";
import Providers from "../components/Providers";
import Nav from "../components/Nav";

export const metadata = { title: "Unbundle fixture" };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-white text-slate-900 antialiased">
        <header className="site-header">FIXTURE_HEADER</header>
        <Nav />
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
