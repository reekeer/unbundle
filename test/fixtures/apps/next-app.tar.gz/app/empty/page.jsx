import Nothing from "../../components/Nothing";

export default function Empty() {
  return (
    <main className="empty">
      <p className="first">RSC_FIRST</p>
      <Nothing />
      <p className="second">RSC_SECOND</p>
    </main>
  );
}
