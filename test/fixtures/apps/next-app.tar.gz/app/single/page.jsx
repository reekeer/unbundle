import Badge from "../../components/Badge";

export default function Single() {
  return (
    <main className="single">
      <p className="before">RSC_BEFORE</p>
      <Badge label="RSC_BADGE" />
      <p className="after">RSC_AFTER</p>
    </main>
  );
}
