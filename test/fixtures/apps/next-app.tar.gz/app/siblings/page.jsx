import Pair from "../../components/Pair";

export default function Siblings() {
  return (
    <main className="siblings">
      <dl>
        <dt className="static-term">RSC_STATIC_TERM</dt>
        <Pair term="RSC_TERM" detail="RSC_DETAIL" />
        <dd className="static-detail">RSC_STATIC_DETAIL</dd>
      </dl>
    </main>
  );
}
