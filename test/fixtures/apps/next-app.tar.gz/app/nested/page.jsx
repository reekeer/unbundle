import Inner from "../../components/Inner";
import Outer from "../../components/Outer";

export default function Nested() {
  return (
    <main className="nested">
      <Outer>
        <p className="server-inside">RSC_SERVER_INSIDE</p>
        <Inner />
      </Outer>
    </main>
  );
}
