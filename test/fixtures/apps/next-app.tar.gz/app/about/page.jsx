import TodoList from "../../components/TodoList";
import Brand from "../../components/Brand";

export default function About() {
  return (
    <main className="p-6">
      <h1 className="text-xl">FIXTURE_ABOUT</h1>
      <TodoList />
      <Brand />
    </main>
  );
}
