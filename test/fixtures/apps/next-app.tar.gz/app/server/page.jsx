import ServerCard from "../../components/ServerCard";

export default function Server() {
  return (
    <main className="server">
      <ServerCard title="RSC_SERVER_TITLE" />
    </main>
  );
}
