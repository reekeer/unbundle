import { Suspense } from "react";

export const dynamic = "force-dynamic";
import Late from "../../components/Late";

async function Slow() {
  await new Promise((resolve) => setTimeout(resolve, 300));
  return (
    <div className="slow">
      <Late value="RSC_LATE" />
    </div>
  );
}

export default function Deferred() {
  return (
    <main className="deferred">
      <p className="shell">RSC_SHELL</p>
      <Suspense fallback={<p className="fallback">RSC_LOADING</p>}>
        <Slow />
      </Suspense>
    </main>
  );
}
