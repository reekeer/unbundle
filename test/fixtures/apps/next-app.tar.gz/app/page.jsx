import Counter from "../components/Counter";
import Toolbar from "../components/Toolbar";

export default function Home() {
  return (
    <main className="index p-6">
      <h1 className="text-2xl font-bold tracking-tight">FIXTURE_HOME</h1>
      <img className="h-5 w-5 rounded" src="/t/tttt/logo.svg" alt="logo" />
      <Counter initial={3} />
      <Toolbar />
    </main>
  );
}
