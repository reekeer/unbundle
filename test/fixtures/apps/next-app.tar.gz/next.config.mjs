export default {
  basePath: "/t/tttt",
  productionBrowserSourceMaps: true,
  images: { unoptimized: true },
  turbopack: { root: import.meta.dirname },
};
