"use client";

import { useEffect, useState } from "react";
import { formatCount } from "../lib/math";
import { useTodoStore } from "../lib/store";

export default function TodoList() {
  const [items, setItems] = useState([]);
  const [draft, setDraft] = useState("");
  const total = useTodoStore((state) => state.total);
  const added = useTodoStore((state) => state.added);

  useEffect(() => {
    if (items.length > 5) console.warn("UNBUNDLE_TODO_OVERFLOW");
  }, [items]);

  function addItem() {
    if (!draft.trim()) return;
    setItems((prev) => [...prev, { id: prev.length + 1, text: draft.trim() }]);
    setDraft("");
    added();
  }

  async function showSummary() {
    const { summarize } = await import("../lib/heavy");
    alert(JSON.stringify(summarize(items)));
  }

  return (
    <section>
      <input value={draft} onChange={(e) => setDraft(e.target.value)} />
      <button onClick={addItem}>Add</button>
      <button onClick={showSummary}>Summary</button>
      <p>{formatCount(items.length)}</p>
      <p>UNBUNDLE_TOTAL {total}</p>
      <ul>
        {items.map((item) => (
          <li key={item.id}>{item.text}</li>
        ))}
      </ul>
    </section>
  );
}
