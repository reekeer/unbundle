"use client";

import { useState } from "react";

export default function Badge({ label }) {
  const [on, setOn] = useState(false);
  return (
    <span className="badge" data-on={on} onClick={() => setOn(!on)}>
      {label}
    </span>
  );
}
