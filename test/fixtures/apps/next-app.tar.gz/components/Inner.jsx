"use client";

import { useState } from "react";

export default function Inner() {
  const [text] = useState("RSC_INNER");
  return <em className="inner">{text}</em>;
}
