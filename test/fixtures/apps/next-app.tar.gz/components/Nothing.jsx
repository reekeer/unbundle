"use client";

import { useEffect } from "react";

export default function Nothing() {
  useEffect(() => {}, []);
  return null;
}
