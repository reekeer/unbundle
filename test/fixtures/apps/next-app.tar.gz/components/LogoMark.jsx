"use client";

export default function LogoMark() {
  return (
    <svg aria-label="Logo" viewBox="0 0 24 24" width="24" height="24">
      <circle cx="12" cy="12" r="10" fill="#0ea5e9" />
      <path d="M7 12h10" stroke="white" strokeWidth="2" />
    </svg>
  );
}
