export default function ServerCard({ title }) {
  return (
    <article className="server-card">
      <h2>{title}</h2>
      <p>RSC_SERVER_ONLY</p>
    </article>
  );
}
