"use client";
import Image from "next/image";
import { useState } from "react";
import { Heart } from "lucide-react";
import LogoMark from "./LogoMark";

function Sparkle() {
  return (
    <svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor">
      <title>Sparkle</title>
      <path d="M8 0l2 6 6 2-6 2-2 6-2-6-6-2 6-2z" />
    </svg>
  );
}

export default function Brand() {
  const [likes, setLikes] = useState(0);
  return (
    <section className="mt-4 flex items-center gap-3">
      <LogoMark />
      <Image src="/t/tttt/pixel.png" alt="pixel" width={16} height={16} />
      <Sparkle />
      <button className="inline-flex items-center gap-1" onClick={() => setLikes((n) => n + 1)}>
        <Heart className="h-4 w-4 text-rose-500" /> LUCIDE_LIKES {likes}
      </button>
    </section>
  );
}
