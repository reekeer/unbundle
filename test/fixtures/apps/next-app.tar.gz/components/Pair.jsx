"use client";

import { useState } from "react";

export default function Pair({ term, detail }) {
  const [open] = useState(true);
  return (
    <>
      <dt className="pair-term">{term}</dt>
      <dd className="pair-detail">{open ? detail : null}</dd>
    </>
  );
}
