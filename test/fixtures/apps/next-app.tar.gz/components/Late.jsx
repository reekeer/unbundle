"use client";

import { useState } from "react";

export default function Late({ value }) {
  const [shown] = useState(value);
  return <b className="late">{shown}</b>;
}
