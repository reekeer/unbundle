"use client";
import Link from "next/link";
import { House, Info } from "lucide-react";

export default function Nav() {
  return (
    <nav className="site-nav flex gap-3 p-2">
      <Link href="/" className="inline-flex items-center gap-1"><House className="h-4 w-4" />Home</Link>
      <Link href="/about/" className="inline-flex items-center gap-1"><Info className="h-4 w-4" />About</Link>
      <a href="/t/tttt/single/">single</a> <a href="/t/tttt/siblings/">siblings</a> <a href="/t/tttt/server/">server</a>{" "}
      <a href="/t/tttt/nested/">nested</a> <a href="/t/tttt/empty/">empty</a> <a href="/t/tttt/deferred/">deferred</a> <a href="/t/tttt/greet/">greet</a>
    </nav>
  );
}
