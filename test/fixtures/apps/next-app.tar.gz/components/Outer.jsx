"use client";

import { useState } from "react";

export default function Outer({ children }) {
  const [count] = useState(1);
  return (
    <section className="outer" data-count={count}>
      {children}
    </section>
  );
}
