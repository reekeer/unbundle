"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Slot } from "@radix-ui/react-slot";
import { clamp, formatCount } from "../lib/math";

export default function Counter({ initial }) {
  const [count, setCount] = useState(initial);
  const isMax = count >= 10;
  const greeting = useQuery({ queryKey: ["greeting"], queryFn: async () => "UNBUNDLE_QUERY_RESULT" });

  return (
    <div className="counter">
      <p>{formatCount(count)}</p>
      <Slot className="greeting">
        <span>{greeting.data ?? "loading"}</span>
      </Slot>
      <button onClick={() => setCount((c) => clamp(c - 1, 0, 10))}>-</button>
      <button disabled={isMax} onClick={() => setCount((c) => clamp(c + 1, 0, 10))}>
        +
      </button>
      {isMax ? <strong>UNBUNDLE_COUNTER_MAX_REACHED</strong> : null}
    </div>
  );
}
