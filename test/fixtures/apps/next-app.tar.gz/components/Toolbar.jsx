"use client";
import { useState } from "react";
import Link from "next/link";
import { ArrowRight, Bell, Search, Settings } from "lucide-react";

export default function Toolbar() {
  const [query, setQuery] = useState("");
  const [muted, setMuted] = useState(false);
  return (
    <div className="flex items-center gap-2 rounded-lg border p-2">
      <Search className="h-4 w-4 text-slate-500" />
      <input className="flex-1 outline-none" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="LUCIDE_SEARCH" />
      <button className="rounded p-1 hover:bg-slate-100" onClick={() => setMuted((m) => !m)} aria-label="Toggle notifications">
        <Bell className={muted ? "h-4 w-4 opacity-40" : "h-4 w-4"} />
      </button>
      <Settings size={18} strokeWidth={1.5} />
      <Link href="/about/" className="toolbar-title inline-flex items-center gap-1 text-sm">
        More <ArrowRight className="h-4 w-4" />
      </Link>
    </div>
  );
}
