import { useState } from "react";
import { useRouter } from "next/router";
import { greet } from "../../lib/greet";

export default function Greet() {
  const router = useRouter();
  const [name, setName] = useState("world");
  return (
    <main>
      <h1>{greet(name)}</h1>
      <input value={name} onChange={(e) => setName(e.target.value)} />
      <button onClick={() => router.push("/greet/settings")}>Settings</button>
    </main>
  );
}
