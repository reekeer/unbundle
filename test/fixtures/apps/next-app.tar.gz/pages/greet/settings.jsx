import { useEffect, useState } from "react";

export default function Settings() {
  const [theme, setTheme] = useState("light");
  useEffect(() => {
    document.body.dataset.theme = theme;
  }, [theme]);
  async function loadReport() {
    const { buildReport } = await import("../../lib/report");
    console.log(buildReport(theme));
  }
  return (
    <section>
      <p>PAGES_ROUTER_SETTINGS_MARKER</p>
      <button onClick={() => setTheme(theme === "light" ? "dark" : "light")}>Toggle</button>
      <button onClick={loadReport}>Report</button>
    </section>
  );
}
