<script>
  import Counter from "$lib/Counter.svelte";
</script>

<h1>KIT_HOME_TITLE</h1>
<Counter initial={3} />
