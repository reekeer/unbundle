<script>
  let { children } = $props();
</script>

<nav class="kit-nav"><a href="/">Home</a> <a href="/about">About</a></nav>
{@render children()}
