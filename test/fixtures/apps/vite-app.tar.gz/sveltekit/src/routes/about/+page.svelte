<script>
  import { total } from "$lib/store.js";
</script>

<h2>KIT_ABOUT_TITLE</h2>
<p>KIT_TOTAL {$total}</p>
