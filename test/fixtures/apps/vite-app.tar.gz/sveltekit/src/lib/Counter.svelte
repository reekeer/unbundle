<script>
  import { total } from "./store.js";
  let { initial = 0 } = $props();
  let count = $state(initial);
  function add() {
    count += 1;
    total.update((n) => n + 1);
  }
</script>

<div class="kit-counter">
  <span>KIT_COUNT {count}</span>
  <button onclick={add}>+</button>
  {#if count >= 10}<strong>KIT_MAX</strong>{/if}
</div>
