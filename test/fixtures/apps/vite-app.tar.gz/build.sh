#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
fixtures="${UNBUNDLE_FIXTURES:-$(dirname "$here")}"
work="$(mktemp -d "${TMPDIR:-/tmp}/unbundle-vite-XXXXXX")"
trap 'rm -rf "$work"' EXIT

publish() {
  mkdir -p "$fixtures/sites"
  COPYFILE_DISABLE=1 tar -czf "$fixtures/sites/$2.tar.gz" -C "$1" .
  echo "built $2"
}

mkdir "$work/spa"
cp -r "$here/src" "$here/index.html" "$here/package.json" "$here/vite.config.js" "$work/spa/"
(cd "$work/spa" && bun install >/dev/null && bun --bun node_modules/vite/bin/vite.js build >/dev/null)
publish "$work/spa/out" site-vite

cp -r "$here/rr7" "$work/rr7"
(cd "$work/rr7" && bun install >/dev/null && node node_modules/@react-router/dev/bin.js build >/dev/null 2>&1)
publish "$work/rr7/build/client" site-rr7

if [ -d "$here/astro" ]; then
  cp -r "$here/astro" "$work/astro"
  (cd "$work/astro" && bun install >/dev/null && node node_modules/astro/astro.js build >/dev/null 2>&1)
  publish "$work/astro/dist" site-astro
fi

if [ -d "$here/sveltekit" ]; then
  cp -r "$here/sveltekit" "$work/sveltekit"
  (cd "$work/sveltekit" && bun install >/dev/null && node node_modules/@sveltejs/kit/svelte-kit.js sync >/dev/null && node node_modules/vite/bin/vite.js build >/dev/null 2>&1)
  publish "$work/sveltekit/build" site-sveltekit
fi

if [ -d "$here/angular" ]; then
  cp -r "$here/angular" "$work/angular"
  (cd "$work/angular" && bun install >/dev/null && NG_CLI_ANALYTICS=false node node_modules/@angular/cli/bin/ng.js build >/dev/null 2>&1)
  publish "$work/angular/dist/shop/browser" site-angular
fi
