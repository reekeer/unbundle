import react from "@vitejs/plugin-react";

export default {
  plugins: [react()],
  build: { outDir: "out", sourcemap: true, emptyOutDir: true },
  logLevel: "warn",
};
