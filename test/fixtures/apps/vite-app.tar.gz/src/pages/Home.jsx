import Counter from "../components/Counter.jsx";

export default function Home() {
  return (
    <main className="home">
      <h1>VITE_HOME_TITLE</h1>
      <Counter initial={3} />
    </main>
  );
}
