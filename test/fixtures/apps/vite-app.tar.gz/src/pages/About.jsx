import { useState } from "react";
import { useTodoStore } from "../lib/store.js";

export default function About() {
  const [items, setItems] = useState([]);
  const total = useTodoStore((state) => state.total);
  const added = useTodoStore((state) => state.added);

  async function showSummary() {
    const { summarize } = await import("../lib/heavy.js");
    console.log(summarize(items));
  }

  return (
    <section className="about">
      <h2>VITE_ABOUT_TITLE</h2>
      <button onClick={() => { setItems((prev) => [...prev, { id: prev.length + 1, text: "todo" }]); added(); }}>Add</button>
      <button onClick={showSummary}>Summary</button>
      <p>VITE_TOTAL {total}</p>
    </section>
  );
}
