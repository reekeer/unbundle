import { useState } from "react";
import clsx from "clsx";
import { Minus, Plus } from "lucide-react";
import { clamp, formatCount } from "../lib/math.js";

export default function Counter({ initial }) {
  const [count, setCount] = useState(initial);
  const isMax = count >= 10;
  return (
    <div className={clsx("counter", isMax && "counter--max")}>
      <p>{formatCount(count)}</p>
      <button onClick={() => setCount((c) => clamp(c - 1, 0, 10))}><Minus size={14} /></button>
      <button disabled={isMax} onClick={() => setCount((c) => clamp(c + 1, 0, 10))}><Plus size={14} /></button>
      {isMax ? <strong>VITE_COUNTER_MAX</strong> : null}
    </div>
  );
}
