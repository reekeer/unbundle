import { lazy, Suspense } from "react";
import { Link, Route, Routes } from "react-router";
import { House, Info } from "lucide-react";
import Home from "./pages/Home.jsx";

const About = lazy(() => import("./pages/About.jsx"));

export default function App() {
  return (
    <div className="app">
      <nav className="site-nav">
        <Link to="/"><House size={16} /> Home</Link>
        <Link to="/about"><Info size={16} /> About</Link>
      </nav>
      <Suspense fallback={<p>VITE_LOADING</p>}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </Suspense>
    </div>
  );
}
