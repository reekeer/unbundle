import { useState } from "react";

export default function ReactCounter({ initial }) {
  const [count, setCount] = useState(initial);
  return (
    <div className="react-counter">
      <span>ASTRO_REACT {count}</span>
      <button onClick={() => setCount((c) => c + 1)}>+</button>
    </div>
  );
}
