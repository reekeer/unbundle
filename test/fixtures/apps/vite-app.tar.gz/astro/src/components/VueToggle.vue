<script setup>
import { ref } from "vue";

const props = defineProps({ label: String });
const open = ref(false);
</script>

<template>
  <div class="vue-toggle">
    <button @click="open = !open">{{ props.label }}</button>
    <p v-if="open">ASTRO_VUE_OPEN</p>
  </div>
</template>
