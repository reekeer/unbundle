<script>
  let { start = 0 } = $props();
  let likes = $state(start);
</script>

<button class="svelte-likes" onclick={() => likes++}>ASTRO_SVELTE {likes}</button>
