import { Component, computed, input, signal } from "@angular/core";
import { clamp } from "../math";

@Component({
  selector: "app-counter",
  template: `
    <div class="counter">
      <button (click)="change(-1)">-</button>
      <span>NG_COUNT {{ count() }}</span>
      <button (click)="change(1)" [disabled]="atMax()">+</button>
      @if (atMax()) {
        <strong>NG_COUNTER_MAX</strong>
      }
    </div>
  `,
})
export class CounterComponent {
  readonly initial = input(0);
  readonly count = signal(0);
  readonly atMax = computed(() => this.count() >= 10);

  ngOnInit(): void {
    this.count.set(this.initial());
  }

  change(step: number): void {
    this.count.update((value) => clamp(value + step, 0, 10));
  }
}
