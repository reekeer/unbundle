import { Injectable, computed, signal } from "@angular/core";

export interface Todo {
  id: number;
  title: string;
  done: boolean;
}

@Injectable({ providedIn: "root" })
export class TodoService {
  private readonly items = signal<Todo[]>([]);
  readonly todos = this.items.asReadonly();
  readonly remaining = computed(() => this.items().filter((todo) => !todo.done).length);

  add(title: string): void {
    this.items.update((items) => [...items, { id: items.length + 1, title, done: false }]);
  }

  toggle(id: number): void {
    this.items.update((items) => items.map((todo) => (todo.id === id ? { ...todo, done: !todo.done } : todo)));
  }
}
