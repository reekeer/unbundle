import { Component, inject } from "@angular/core";
import { TodoService } from "./todo.service";
import { ShoutPipe } from "./shout.pipe";

@Component({
  selector: "app-todo-list",
  imports: [ShoutPipe],
  template: `
    <section class="todos">
      <button (click)="add()">NG_ADD_TODO</button>
      @for (todo of service.todos(); track todo.id) {
        <label [class.done]="todo.done">
          <input type="checkbox" [checked]="todo.done" (change)="service.toggle(todo.id)" />
          {{ todo.title | shout }}
        </label>
      } @empty {
        <p>NG_TODO_EMPTY</p>
      }
      <small>NG_REMAINING {{ service.remaining() }}</small>
    </section>
  `,
})
export class TodoListComponent {
  readonly service = inject(TodoService);

  add(): void {
    this.service.add(`Task ${this.service.todos().length + 1}`);
  }
}
