import { Component } from "@angular/core";
import { CounterComponent } from "./counter/counter.component";
import { TodoListComponent } from "./todos/todo-list.component";

@Component({
  selector: "app-home",
  imports: [CounterComponent, TodoListComponent],
  template: `
    <h1>NG_HOME_TITLE</h1>
    <app-counter [initial]="3" />
    <app-todo-list />
  `,
})
export class HomeComponent {}
