import { Component } from "@angular/core";

@Component({
  selector: "app-about",
  template: `<h1>NG_ABOUT_TITLE</h1><p>NG_LAZY_ROUTE</p>`,
})
export class AboutComponent {}
