import { useState } from "react";

export function meta() {
  return [{ title: "RR7_HOME_META" }];
}

export default function Home() {
  const [count, setCount] = useState(2);
  return (
    <main className="home">
      <h1>RR7_HOME_TITLE</h1>
      <button onClick={() => setCount((c) => c + 1)}>RR7_COUNT {count}</button>
    </main>
  );
}
