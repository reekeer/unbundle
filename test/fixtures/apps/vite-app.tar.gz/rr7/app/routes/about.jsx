import { useLoaderData } from "react-router";

export async function clientLoader() {
  return { message: "RR7_LOADER_MESSAGE" };
}

export default function About() {
  const data = useLoaderData();
  return (
    <section className="about">
      <h2>RR7_ABOUT_TITLE</h2>
      <p>{data?.message}</p>
    </section>
  );
}
