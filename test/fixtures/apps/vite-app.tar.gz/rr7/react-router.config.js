export default { ssr: false, prerender: ["/", "/about"] };
