import tailwindcss from "@tailwindcss/vite";

export default defineNuxtConfig({
  compatibilityDate: "2026-09-01",
  modules: ["@pinia/nuxt"],
  css: ["~/assets/main.css"],
  vite: { plugins: [tailwindcss()] },
  sourcemap: { client: true },
  telemetry: false,
});
