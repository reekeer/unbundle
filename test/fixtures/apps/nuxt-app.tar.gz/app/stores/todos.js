import { defineStore } from "pinia";

export const useTodoStore = defineStore("todos", {
  state: () => ({ items: [] }),
  getters: {
    total: (state) => state.items.length,
  },
  actions: {
    add(text) {
      this.items.push({ id: this.items.length + 1, text, done: false });
    },
  },
});
