<script setup>
import Counter from "../components/Counter.vue";
</script>

<template>
  <main class="p-6">
    <h1 class="text-2xl font-bold">NUXT_HOME_TITLE</h1>
    <Counter :initial="3" />
  </main>
</template>
