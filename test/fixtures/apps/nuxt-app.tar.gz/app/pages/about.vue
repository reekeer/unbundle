<script setup>
import { ref } from "vue";
import TodoList from "../components/TodoList.vue";
import ItemCard from "../components/ItemCard.vue";

const removed = ref(0);
const tag = "aside";
const sample = { id: 7, text: "NUXT_SAMPLE" };

function onRemove(id) {
  removed.value += id;
}
</script>

<template>
  <main class="p-6">
    <h1>NUXT_ABOUT_TITLE</h1>
    <TodoList />
    <ItemCard :item="sample" :extra="{ 'data-kind': 'demo' }" @remove="onRemove">
      <template #title="{ text }"><b>{{ text }}</b></template>
    </ItemCard>
    <component :is="tag">NUXT_REMOVED {{ removed }}</component>
  </main>
</template>
