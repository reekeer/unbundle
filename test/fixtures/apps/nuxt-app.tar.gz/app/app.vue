<script setup>
import { House, Info } from "lucide-vue-next";
</script>

<template>
  <header class="nav flex gap-3 p-2">
    <NuxtLink to="/" class="inline-flex items-center gap-1"><House class="h-4 w-4" />Home</NuxtLink>
    <NuxtLink to="/about" class="inline-flex items-center gap-1"><Info class="h-4 w-4" />About</NuxtLink>
  </header>
  <NuxtPage />
</template>
