<script setup>
import { computed, ref } from "vue";
import { Minus, Plus } from "lucide-vue-next";
import { clamp } from "../utils/math.js";

const props = defineProps({ initial: { type: Number, default: 3 } });
const count = ref(props.initial);
const isMax = computed(() => count.value >= 10);

function increment() {
  count.value = clamp(count.value + 1, 0, 10);
}
</script>

<template>
  <div class="counter">
    <p>{{ count }} NUXT_COUNTER_ITEMS</p>
    <button :disabled="isMax" @click="increment"><Plus class="h-4 w-4" /></button>
    <button @click="count = clamp(count - 1, 0, 10)"><Minus class="h-4 w-4" /></button>
    <strong v-if="isMax">NUXT_COUNTER_MAX</strong>
  </div>
</template>

<style scoped>
.counter {
  color: seagreen;
}
</style>
