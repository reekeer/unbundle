<script setup>
import { ref } from "vue";
import { Trash2 } from "lucide-vue-next";
import { useTodoStore } from "../stores/todos.js";

const store = useTodoStore();
const draft = ref("");

function addItem() {
  if (!draft.value.trim()) return;
  store.add(draft.value.trim());
  draft.value = "";
}
</script>

<template>
  <section>
    <input v-model="draft" placeholder="NUXT_TODO_PLACEHOLDER" />
    <button @click="addItem">Add</button>
    <ul>
      <li v-for="item in store.items" :key="item.id">{{ item.text }} <Trash2 class="h-3 w-3" /></li>
    </ul>
    <p>NUXT_TOTAL {{ store.total }}</p>
  </section>
</template>
