<script setup>
const props = defineProps({ item: Object, extra: Object });
const emit = defineEmits(["remove"]);
</script>

<template>
  <article class="item-card" v-bind="extra">
    <slot name="title" :text="item.text">{{ item.text }}</slot>
    <button @click="emit('remove', item.id)">NUXT_REMOVE</button>
  </article>
</template>

<style scoped>
.item-card {
  border: 1px solid #ccc;
}
</style>
