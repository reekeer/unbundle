#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
fixtures="${UNBUNDLE_FIXTURES:-$(dirname "$here")}"
work="$(mktemp -d "${TMPDIR:-/tmp}/unbundle-nuxt-XXXXXX")"
trap 'rm -rf "$work"' EXIT
cp -r "$here/app" "$here/package.json" "$here/nuxt.config.ts" "$work/"
cd "$work"
export NUXT_TELEMETRY_DISABLED=1
bun install >/dev/null
bun --bun node_modules/nuxt/bin/nuxt.mjs generate >/dev/null
mkdir -p "$fixtures/sites"
COPYFILE_DISABLE=1 tar -czf "$fixtures/sites/site-nuxt.tar.gz" -C .output/public .
echo "built site-nuxt"
